package com.jb.spring_coupons_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCouponsProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
