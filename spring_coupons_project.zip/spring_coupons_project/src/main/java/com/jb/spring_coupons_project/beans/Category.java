package com.jb.spring_coupons_project.beans;

public enum Category {

    FOOD,
    ELECTRICITY,

    RESTAURANT,
    VACATION,

    SPA,

    ATTRACTIONS,

    GIFT_CARD,

    CLOTHING,

    BOWLING,

    SHOWS,

    FLIGHTS,

    HOTELS,

    PERFUMES,

    HOME_PRODUCTS,

    COURSES
}
