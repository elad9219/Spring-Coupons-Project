package com.jb.spring_coupons_project.exception;

public class TokenException extends Exception {
    public TokenException() {
    }

    public TokenException(String message) {
        super(message);
    }
}
