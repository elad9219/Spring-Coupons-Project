package com.jb.spring_coupons_project.beans;

public enum UserType {
    ADMIN,
    COMPANY,
    CUSTOMER
}
