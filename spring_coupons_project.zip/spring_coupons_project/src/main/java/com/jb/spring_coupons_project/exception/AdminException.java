package com.jb.spring_coupons_project.exception;

public class AdminException extends Exception {
    public AdminException() {
    }

    public AdminException(String message) {
        super(message);
    }
}
